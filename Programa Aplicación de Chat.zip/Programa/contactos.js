const contacts = [
    { name: "Juan", status: "en línea" },
    { name: "Pedro", status: "desconectado" },
    { name: "María", status: "en línea" }
  ];
  
  const contactList = document.getElementById("contact-list");
  
  for (let i = 0; i < contacts.length; i++) {
    const contact = contacts[i];
    const contactElement = document.createElement("div");
    contactElement.innerHTML = `${contact.name} - ${contact.status}`;
    contactList.appendChild(contactElement);
  }