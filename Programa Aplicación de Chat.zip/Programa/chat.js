function enviarMensaje() {
    var messageInput = document.getElementById("message-input");
    var messageContainer = document.getElementById("message-container");

    var message = messageInput.value;
    var messageElement = document.createElement("div");
    messageElement.innerText = message;

    messageContainer.appendChild(messageElement);
    messageInput.value = "";
  }

  function borrarMensajes() {
    var messageContainer = document.getElementById("message-container");
    messageContainer.innerHTML = "";
  }